<?php

include_once NEOOCULAR_CORE_INC_PATH . '/core-dashboard/sub-pages/system-info/class-neoocularcore-dashboard-system-info-page.php';
