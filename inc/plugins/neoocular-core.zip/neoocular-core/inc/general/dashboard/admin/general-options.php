<?php

if ( ! function_exists( 'neoocular_core_add_general_options' ) ) {
	/**
	 * Function that add general options for this module
	 */
	function neoocular_core_add_general_options( $page ) {

		if ( $page ) {
			$page->add_field_element(
				array(
					'field_type'  => 'color',
					'name'        => 'qodef_main_color',
					'title'       => esc_html__( 'Main Color', 'neoocular-core' ),
					'description' => esc_html__( 'Choose the most dominant theme color', 'neoocular-core' ),
				)
			);

			$page->add_field_element(
				array(
					'field_type'  => 'color',
					'name'        => 'qodef_page_background_color',
					'title'       => esc_html__( 'Page Background Color', 'neoocular-core' ),
					'description' => esc_html__( 'Set background color', 'neoocular-core' ),
				)
			);

			$page->add_field_element(
				array(
					'field_type'  => 'image',
					'name'        => 'qodef_page_background_image',
					'title'       => esc_html__( 'Page Background Image', 'neoocular-core' ),
					'description' => esc_html__( 'Set background image', 'neoocular-core' ),
				)
			);

			$page->add_field_element(
				array(
					'field_type'  => 'select',
					'name'        => 'qodef_page_background_repeat',
					'title'       => esc_html__( 'Page Background Image Repeat', 'neoocular-core' ),
					'description' => esc_html__( 'Set background image repeat', 'neoocular-core' ),
					'options'     => array(
						''          => esc_html__( 'Default', 'neoocular-core' ),
						'no-repeat' => esc_html__( 'No Repeat', 'neoocular-core' ),
						'repeat'    => esc_html__( 'Repeat', 'neoocular-core' ),
						'repeat-x'  => esc_html__( 'Repeat-x', 'neoocular-core' ),
						'repeat-y'  => esc_html__( 'Repeat-y', 'neoocular-core' ),
					),
				)
			);

			$page->add_field_element(
				array(
					'field_type'  => 'select',
					'name'        => 'qodef_page_background_size',
					'title'       => esc_html__( 'Page Background Image Size', 'neoocular-core' ),
					'description' => esc_html__( 'Set background image size', 'neoocular-core' ),
					'options'     => array(
						''        => esc_html__( 'Default', 'neoocular-core' ),
						'contain' => esc_html__( 'Contain', 'neoocular-core' ),
						'cover'   => esc_html__( 'Cover', 'neoocular-core' ),
					),
				)
			);

			$page->add_field_element(
				array(
					'field_type'  => 'select',
					'name'        => 'qodef_page_background_attachment',
					'title'       => esc_html__( 'Page Background Image Attachment', 'neoocular-core' ),
					'description' => esc_html__( 'Set background image attachment', 'neoocular-core' ),
					'options'     => array(
						''       => esc_html__( 'Default', 'neoocular-core' ),
						'fixed'  => esc_html__( 'Fixed', 'neoocular-core' ),
						'scroll' => esc_html__( 'Scroll', 'neoocular-core' ),
					),
				)
			);

			$page->add_field_element(
				array(
					'field_type'  => 'text',
					'name'        => 'qodef_page_content_padding',
					'title'       => esc_html__( 'Page Content Padding', 'neoocular-core' ),
					'description' => esc_html__( 'Set padding that will be applied for page content in format: top right bottom left (e.g. 10px 5px 10px 5px)', 'neoocular-core' ),
				)
			);

			$page->add_field_element(
				array(
					'field_type'  => 'text',
					'name'        => 'qodef_page_content_padding_mobile',
					'title'       => esc_html__( 'Page Content Padding Mobile', 'neoocular-core' ),
					'description' => esc_html__( 'Set padding that will be applied for page content on mobile screens (1024px and below) in format: top right bottom left (e.g. 10px 5px 10px 5px)', 'neoocular-core' ),
				)
			);

			$page->add_field_element(
				array(
					'field_type'    => 'yesno',
					'name'          => 'qodef_boxed',
					'title'         => esc_html__( 'Boxed Layout', 'neoocular-core' ),
					'description'   => esc_html__( 'Set boxed layout', 'neoocular-core' ),
					'default_value' => 'no',
				)
			);

			$boxed_section = $page->add_section_element(
				array(
					'name'       => 'qodef_boxed_section',
					'title'      => esc_html__( 'Boxed Layout Section', 'neoocular-core' ),
					'dependency' => array(
						'hide' => array(
							'qodef_boxed' => array(
								'values'        => 'no',
								'default_value' => '',
							),
						),
					),
				)
			);

			$boxed_section->add_field_element(
				array(
					'field_type'  => 'color',
					'name'        => 'qodef_boxed_background_color',
					'title'       => esc_html__( 'Boxed Background Color', 'neoocular-core' ),
					'description' => esc_html__( 'Set boxed background color', 'neoocular-core' ),
				)
			);

			$boxed_section->add_field_element(
				array(
					'field_type'  => 'image',
					'name'        => 'qodef_boxed_background_pattern',
					'title'       => esc_html__( 'Boxed Background Pattern', 'neoocular-core' ),
					'description' => esc_html__( 'Set boxed background pattern', 'neoocular-core' ),
				)
			);

			$boxed_section->add_field_element(
				array(
					'field_type'  => 'select',
					'name'        => 'qodef_boxed_background_pattern_behavior',
					'title'       => esc_html__( 'Boxed Background Pattern Behavior', 'neoocular-core' ),
					'description' => esc_html__( 'Set boxed background pattern behavior', 'neoocular-core' ),
					'options'     => array(
						'fixed'  => esc_html__( 'Fixed', 'neoocular-core' ),
						'scroll' => esc_html__( 'Scroll', 'neoocular-core' ),
					),
				)
			);

			$page->add_field_element(
				array(
					'field_type'    => 'yesno',
					'name'          => 'qodef_passepartout',
					'title'         => esc_html__( 'Passepartout', 'neoocular-core' ),
					'description'   => esc_html__( 'Enabling this option will display a passepartout around website content', 'neoocular-core' ),
					'default_value' => 'no',
				)
			);

			$passepartout_section = $page->add_section_element(
				array(
					'name'       => 'qodef_passepartout_section',
					'title'      => esc_html__( 'Passepartout Section', 'neoocular-core' ),
					'dependency' => array(
						'hide' => array(
							'qodef_passepartout' => array(
								'values'        => 'no',
								'default_value' => '',
							),
						),
					),
				)
			);

			$passepartout_section->add_field_element(
				array(
					'field_type'  => 'color',
					'name'        => 'qodef_passepartout_color',
					'title'       => esc_html__( 'Passepartout Color', 'neoocular-core' ),
					'description' => esc_html__( 'Choose background color for passepartout', 'neoocular-core' ),
				)
			);

			$passepartout_section->add_field_element(
				array(
					'field_type'  => 'image',
					'name'        => 'qodef_passepartout_image',
					'title'       => esc_html__( 'Passepartout Background Image', 'neoocular-core' ),
					'description' => esc_html__( 'Set background image for passepartout', 'neoocular-core' ),
				)
			);

			$passepartout_section->add_field_element(
				array(
					'field_type'  => 'text',
					'name'        => 'qodef_passepartout_size',
					'title'       => esc_html__( 'Passepartout Size', 'neoocular-core' ),
					'description' => esc_html__( 'Enter size amount for passepartout', 'neoocular-core' ),
					'args'        => array(
						'suffix' => esc_html__( 'px or %', 'neoocular-core' ),
					),
				)
			);

			$passepartout_section->add_field_element(
				array(
					'field_type'  => 'text',
					'name'        => 'qodef_passepartout_size_responsive',
					'title'       => esc_html__( 'Passepartout Responsive Size', 'neoocular-core' ),
					'description' => esc_html__( 'Enter size amount for passepartout for smaller screens (1024px and below)', 'neoocular-core' ),
					'args'        => array(
						'suffix' => esc_html__( 'px or %', 'neoocular-core' ),
					),
				)
			);

			$page->add_field_element(
				array(
					'field_type'    => 'select',
					'name'          => 'qodef_content_width',
					'title'         => esc_html__( 'Initial Width of Content', 'neoocular-core' ),
					'description'   => esc_html__( 'Choose the initial width of content which is in grid (applies to pages set to "Default Template" and rows set to "In Grid")', 'neoocular-core' ),
					'options'       => neoocular_core_get_select_type_options_pool( 'content_width', false ),
					'default_value' => '1400',
				)
			);

			// Hook to include additional options after module options
			do_action( 'neoocular_core_action_after_general_options_map', $page );

			$page->add_field_element(
				array(
					'field_type'  => 'textarea',
					'name'        => 'qodef_custom_js',
					'title'       => esc_html__( 'Custom JS', 'neoocular-core' ),
					'description' => esc_html__( 'Enter your custom JavaScript here', 'neoocular-core' ),
				)
			);
		}
	}

	add_action( 'neoocular_core_action_default_options_init', 'neoocular_core_add_general_options', neoocular_core_get_admin_options_map_position( 'general' ) );
}
