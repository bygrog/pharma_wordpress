<?php

if ( qode_framework_is_installed( 'elementor' ) ) {
	include_once NEOOCULAR_CORE_PLUGINS_PATH . '/elementor/helper.php';
	include_once NEOOCULAR_CORE_PLUGINS_PATH . '/elementor/class-neoocularcore-elementor-section-handler.php';
}
