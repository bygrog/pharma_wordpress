<div class="qodef-woo-product-price price"><?php echo qode_framework_wp_kses_html( 'content', $product->get_price_html() ); ?></div>
