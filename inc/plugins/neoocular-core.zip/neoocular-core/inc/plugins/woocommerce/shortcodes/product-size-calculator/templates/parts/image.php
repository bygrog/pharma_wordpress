<div class="qodef-e-image">
	<?php if ( ! empty( $image_label_bottom ) ) { ?>
		<span class="qodef-bottom-text"><?php echo esc_html( $image_label_bottom ); ?></span>
	<?php } ?>
	<?php if ( ! empty( $image_label_left ) ) { ?>
		<span class="qodef-left-text"><?php echo esc_html( $image_label_left ); ?></span>
	<?php } ?>
</div>
