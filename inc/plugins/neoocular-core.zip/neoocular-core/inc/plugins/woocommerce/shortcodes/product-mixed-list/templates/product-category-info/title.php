<h2 class="woocommerce-loop-category__title" <?php qode_framework_inline_style( $this_shortcode->get_title_styles( $params ) ); ?>>
	<?php echo get_the_category_by_ID( $category_id ); ?>
</h2>
