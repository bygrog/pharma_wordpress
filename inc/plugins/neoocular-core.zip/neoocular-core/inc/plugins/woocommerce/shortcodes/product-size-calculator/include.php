<?php

include_once NEOOCULAR_CORE_PLUGINS_PATH . '/woocommerce/shortcodes/product-size-calculator/class-neoocularcore-product-size-calculator-shortcode.php';
