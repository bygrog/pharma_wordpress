(function ( $ ) {
	'use strict';

	var shortcode = 'neoocular_core_product_size_calculator';

	$( window ).on(
		'load',
		function () {
			qodefProductSizeCalculator.init();
		}
	);

	var qodefProductSizeCalculator = {
		init: function () {
			this.holder = $( '.qodef-product-size-calculator' );

			if ( this.holder.length ) {
				this.holder.each(
					function () {
						var $form = $( this );

						qodefProductSizeCalculator.triggerSearch( $form );
					}
				);
			}
		},
		getSearchData: function ( $form ) {
			var $input       = $form.find( '.qodef-product-search-form-field' ),
				$value       = $input.val(),
				$xs          = 120,
				$s           = 140,
				$m           = 160,
				$l           = 180,
				$xl          = 200,
				$searchValue = '';

			if ( '' !== $value && null !== $value ) {
				if ( $value <= $xs ) {
					$searchValue = 'xs';
				} else if ( $value <= $s ) {
					$searchValue = 's';
				} else if ( $value <= $m ) {
					$searchValue = 'm';
				} else if ( $value <= $l ) {
					$searchValue = 'l';
				} else if ( $value <= $xl ) {
					$searchValue = 'xl';
				} else if ( $value > $xl ) {
					$searchValue = 'xl';
				}

				qodefProductSizeCalculator.displayResult(
					$form,
					$value,
					$searchValue
				);
			} else {
				$input.css( 'border-color' , 'red' );
			}
		},
		triggerSearch: function ( $form ) {
			$form.find( '.qodef-button.qodef-calculate' ).on(
				'click',
				function ( e ) {
					e.preventDefault();

					qodefProductSizeCalculator.getSearchData( $form );

					setTimeout(
						function () {
							$( this ).parents( 'form' ).trigger( 'submit' );
						},
						600
					);
				}
			);
		},
		displayResult: function ( $form, $value, $searchValue ) {
			var $formInit       = $form.find( '.qodef-size-search-form-inner' ),
				$result         = $form.find( '.qodef-size-display' ),
				$inputHolder    = $result.find( '#qodef-input-value' ),
				$sizeHolder     = $result.find( '#qodef-size-value' ),
				$linkAction     = $result.find( '.qodef-button.qodef-html--link' ),
				$link           = $linkAction.attr( 'href' ),
				$recalculateBtn = $result.find( '.qodef-button.qodef-recalculate' );

			if ( '' !== $value && '' !== $searchValue ) {
				$inputHolder.text( $value + 'mm' );
				$sizeHolder.text( $searchValue );
				$result.css(
					'display',
					'flex'
				);
				$formInit.css(
					'display',
					'none'
				);
				$linkAction.attr(
					'href',
					$link + '/?filter_size=' + $searchValue
				);
			}

			$recalculateBtn.on(
				'click',
				function () {
					var $input = $form.find( '.qodef-product-search-form-field' );

					$input.val( '' );
					$linkAction.attr(
						'href',
						$link
					);
					$result.css(
						'display',
						'none'
					);
					$formInit.css(
						'display',
						'block',
					);
					$input.css(
						'border-color',
						'#eee',
					);
				}
			);
		},
	};

	qodefCore.shortcodes[shortcode]                            = {};
	qodefCore.shortcodes[shortcode].qodefProductSizeCalculator = qodefProductSizeCalculator;

})( jQuery );
