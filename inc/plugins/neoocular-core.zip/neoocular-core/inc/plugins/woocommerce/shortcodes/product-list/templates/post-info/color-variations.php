<?php if ( 'yes' === $enable_color_variation ) { ?>
	<div class="qodef-woo-color-variations-holder">
		<?php
		// Hook to include additional content inside product list item image
		do_action( 'neoocular_core_action_product_list_item_color_variations' );
		?>
	</div>
<?php } ?>
