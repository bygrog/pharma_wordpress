<?php

if ( ! function_exists( 'neoocular_core_add_product_mixed_list_shortcode' ) ) {
	/**
	 * Function that is adding shortcode into shortcodes list for registration
	 *
	 * @param array $shortcodes - Array of registered shortcodes
	 *
	 * @return array
	 */
	function neoocular_core_add_product_mixed_list_shortcode( $shortcodes ) {
		$shortcodes[] = 'NeoOcularCore_Product_Mixed_List_Shortcode';

		return $shortcodes;
	}

	add_filter( 'neoocular_core_filter_register_shortcodes', 'neoocular_core_add_product_mixed_list_shortcode' );
}

if ( class_exists( 'NeoOcularCore_List_Shortcode' ) ) {
	class NeoOcularCore_Product_Mixed_List_Shortcode extends NeoOcularCore_List_Shortcode {

		public function __construct() {
			$this->set_post_type( 'product' );
			$this->set_post_type_taxonomy( 'product_cat' );
			$this->set_post_type_additional_taxonomies( array( 'product_tag', 'product_type' ) );
			$this->set_layouts( apply_filters( 'neoocular_core_filter_product_mixed_list_layouts', array() ) );
			$this->set_extra_options( apply_filters( 'neoocular_core_filter_product_mixed_list_extra_options', array() ) );

			parent::__construct();
		}

		public function map_shortcode() {
			$this->set_shortcode_path( NEOOCULAR_CORE_PLUGINS_URL_PATH . '/woocommerce/shortcodes/product-mixed-list' );
			$this->set_base( 'neoocular_core_product_mixed_list' );
			$this->set_name( esc_html__( 'Product Mixed List', 'neoocular-core' ) );
			$this->set_description( esc_html__( 'Shortcode that displays list of products and product categories', 'neoocular-core' ) );
			$this->set_category( esc_html__( 'NeoOcular Core', 'neoocular-core' ) );
			$this->set_option(
				array(
					'field_type' => 'text',
					'name'       => 'custom_class',
					'title'      => esc_html__( 'Custom Class', 'neoocular-core' ),
				)
			);
			$this->set_option(
				array(
					'field_type'    => 'select',
					'name'          => 'behavior',
					'title'         => esc_html__( 'List Appearance', 'breton-core' ),
					'options'       => array(
						'masonry' => esc_html__( 'Masonry', 'breton-core' ),
					),
					'default_value' => 'masonry',
					'visibility'    => array( 'map_for_page_builder' => false ),
				)
			);
			$this->set_option(
				array(
					'field_type'    => 'select',
					'name'          => 'columns',
					'title'         => esc_html__( 'Number of Columns', 'neoocular-core' ),
					'options'       => neoocular_core_get_select_type_options_pool( 'columns_number', true ),
					'default_value' => '3',
					'visibility'    => array( 'map_for_page_builder' => false ),
				)
			);
			$this->set_option(
				array(
					'field_type' => 'repeater',
					'name'       => 'children',
					'title'      => esc_html__( 'Items', 'neoocular-core' ),
					'items'      => array(
						array(
							'field_type'    => 'select',
							'name'          => 'item_type',
							'title'         => esc_html__( 'Item Type', 'neoocular-core' ),
							'options'       => array(
								'product'     => esc_html__( 'Product', 'neoocular-core' ),
								'product_cat' => esc_html__( 'Product Category', 'neoocular-core' ),
							),
							'default_value' => 'product',
						),
						array(
							'field_type' => 'text',
							'name'       => 'item_id',
							'title'      => esc_html__( 'Item ID', 'neoocular-core' ),
						),
						array(
							'field_type'    => 'select',
							'name'          => 'item_hover',
							'title'         => esc_html__( 'Item Hover', 'neoocular-core' ),
							'options'       => array(
								'button' => esc_html__( 'Hover Button', 'neoocular-core' ),
								'info'   => esc_html__( 'Hover Info', 'neoocular-core' ),
							),
							'default_value' => 'button',
							'dependency'    => array(
								'show' => array(
									'item_type' => array(
										'values'        => 'product',
										'default_value' => 'product',
									),
								),
							),
						),
					),
				)
			);
			$this->map_additional_options();
			$this->map_extra_options();
		}

		public static function call_shortcode( $params ) {
			$html = qode_framework_call_shortcode( 'neoocular_core_product_mixed_list', $params );
			$html = str_replace( "\n", '', $html );

			return $html;
		}

		public function render( $options, $content = null ) {
			parent::render( $options );

			$atts = $this->get_atts();

			$atts['holder_classes'] = $this->get_holder_classes( $atts );
			$atts['items']          = $this->parse_repeater_items( $atts['children'] );
			$atts['this_shortcode'] = $this;

			return neoocular_core_get_template_part( 'plugins/woocommerce/shortcodes/product-mixed-list', 'templates/content', '', $atts );
		}

		private function get_holder_classes( $atts ) {
			$holder_classes = $this->init_holder_classes();

			$holder_classes[] = 'qodef-woo-shortcode';
			$holder_classes[] = 'qodef-woo-product-list';
			$holder_classes[] = 'qodef-woo-product-mixed-list';
			$holder_classes[] = 'qodef-grid';
			$holder_classes[] = 'qodef-layout--masonry';
			$holder_classes[] = 'qodef-item-layout--info-on-image';
			$holder_classes[] = ! empty( $atts['columns'] ) ? 'qodef-col-num--' . $atts['columns'] : '';
			$holder_classes[] = 'qodef-gutter--no';
			$holder_classes[] = 'qodef-items--fixed';
			$holder_classes[] = 'qodef-responsive--custom';
			$holder_classes[] = 'qodef-col-num--1440--3';
			$holder_classes[] = 'qodef-col-num--1366--3';
			$holder_classes[] = 'qodef-col-num--1024--2';
			$holder_classes[] = 'qodef-col-num--768--2';
			$holder_classes[] = 'qodef-col-num--680--1';
			$holder_classes[] = 'qodef-col-num--480--1';

			return implode( ' ', $holder_classes );
		}

		public function get_item_classes( $params ) {
			$item_classes[] = 'qodef-e';
			$item_classes[] = 'qodef-grid-item';

			return implode( ' ', $item_classes );
		}

		public function get_title_styles( $atts ) {
			$styles = array();

			if ( ! empty( $atts['text_transform'] ) ) {
				$styles[] = 'text-transform: ' . $atts['text_transform'];
			}

			return $styles;
		}
	}
}
