<?php
if ( ! empty( $product ) && $product->is_on_sale() && $product->is_in_stock() ) {
	echo neoocular_woo_get_woocommerce_sale( $product );
}
