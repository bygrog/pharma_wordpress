<?php

class NeoOcular_Product_Size_Calculator_Shortcode_Elementor extends NeoOcularCore_Elementor_Widget_Base {

	public function __construct( array $data = [], $args = null ) {
		$this->set_shortcode_slug( 'neoocular_core_product_size_calculator' );

		parent::__construct( $data, $args );
	}
}

if ( qode_framework_is_installed( 'woocommerce' ) ) {
	neoocular_core_get_elementor_widgets_manager()->register_widget_type( new NeoOcular_Product_Size_Calculator_Shortcode_Elementor() );
}
