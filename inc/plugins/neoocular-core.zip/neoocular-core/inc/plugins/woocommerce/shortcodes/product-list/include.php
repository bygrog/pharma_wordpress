<?php

include_once NEOOCULAR_CORE_PLUGINS_PATH . '/woocommerce/shortcodes/product-list/class-neoocularcore-product-list-shortcode.php';

foreach ( glob( NEOOCULAR_CORE_PLUGINS_PATH . '/woocommerce/shortcodes/product-list/variations/*/include.php' ) as $variation ) {
	include_once $variation;
}
