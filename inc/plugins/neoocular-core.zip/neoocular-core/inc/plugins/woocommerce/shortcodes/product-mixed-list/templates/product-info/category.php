<?php
$categories = wp_get_post_terms( $product->get_id(), 'product_cat' );
if ( ! empty( $categories ) ) { ?>
	<div class="qodef-woo-product-categories qodef-e-info">
		<?php foreach ( $categories as $category ) { ?>
			<a href="<?php echo get_term_link( $category ); ?>" rel="tag">
				<?php echo wp_kses_post( $category->name ); ?>
			</a>
			<span class="qodef-info-separator-single"></span>
		<?php } ?>
	</div>
<?php } ?>
