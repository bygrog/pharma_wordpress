<?php

include_once NEOOCULAR_CORE_PLUGINS_PATH . '/woocommerce/shortcodes/product-mixed-list/class-neoocularcore-product-mixed-list-shortcode.php';
