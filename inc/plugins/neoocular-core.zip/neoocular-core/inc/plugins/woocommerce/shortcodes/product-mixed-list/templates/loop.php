<?php
if ( ! empty( $items ) ) {
	foreach ( $items as $item ) {
		if ( 'product' === $item['item_type'] ) {
			$params['id'] = $item['item_id'];
			$item_skin    = neoocular_core_get_post_value_through_levels( 'qodef_product_list_skin', $item['item_id'] );
			$skin_class   = '';
			$hover_class  = '';
			if ( ! empty( $item_skin ) ) {
				$skin_class = 'qodef-skin--' . $item_skin;
			}
			if ( ! empty( $item['item_hover'] ) ) {
				$hover_class = 'qodef-hover--' . $item['item_hover'];
			}
			$params['masonry_params'] = neoocular_core_get_custom_image_size_meta( 'meta-box', 'qodef_masonry_image_dimension_product', $item['item_id'] );
			$params['item_classes']   = $this_shortcode->get_item_classes( $params ) . ' ' . $params['masonry_params']['class'] . ' ' . $skin_class . ' ' . $hover_class;
			neoocular_core_template_part( 'plugins/woocommerce/shortcodes/product-mixed-list', 'templates/product', '', $params );
		} else {
			$params['id']             = $item['item_id'];
			$content_align            = get_term_meta( $item['item_id'], 'qodef_product_category_mixed_list_content_align', true );
			$params['masonry_params'] = neoocular_core_get_custom_image_size_meta( 'taxonomy', 'qodef_product_category_masonry_size', $item['item_id'] );
			$params['item_classes']   = $this_shortcode->get_item_classes( $params ) . ' ' . $params['masonry_params']['class'] . ' ' . 'qodef-content-align-' . $content_align;
			neoocular_core_template_part( 'plugins/woocommerce/shortcodes/product-mixed-list', 'templates/product-category', '', $params );
		}
	} // End of the loop.
} else {
	// Include global posts not found
	neoocular_core_theme_template_part( 'content', 'templates/parts/posts-not-found' );
}
