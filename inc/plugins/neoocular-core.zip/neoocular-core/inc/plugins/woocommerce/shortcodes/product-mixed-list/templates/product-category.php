<?php
$category              = get_term( $id );
$category_image        = get_term_meta( $id, 'thumbnail_id', true );
$params['category_id'] = $id;
$params['category']    = $category;
?>
<div <?php wc_product_class( $item_classes ); ?>>
	<div class="qodef-e-inner">
		<?php if ( ! empty( $category_image ) ) { ?>
			<div class="qodef-woo-product-category-image">
				<?php
				neoocular_core_template_part( 'plugins/woocommerce/shortcodes/product-mixed-list', 'templates/product-category-info/image', '', $params );
				?>
				<div class="qodef-woo-product-category-content">
					<div class="qodef-woo-product-category-info">
						<?php neoocular_core_template_part( 'plugins/woocommerce/shortcodes/product-mixed-list', 'templates/product-category-info/title', '', $params ); ?>
						<?php neoocular_core_template_part( 'plugins/woocommerce/shortcodes/product-mixed-list', 'templates/product-category-info/description', '', $params ); ?>
						<?php neoocular_core_template_part( 'plugins/woocommerce/shortcodes/product-mixed-list', 'templates/product-category-info/show-more', '', $params ); ?>
					</div>
				</div>
			</div>
		<?php } ?>
	</div>
</div>
