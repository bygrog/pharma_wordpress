<?php
$product_list_image = get_post_meta( $id, 'qodef_product_list_image', true );
$has_image          = ! empty( $product_list_image ) || ! empty( $product->get_image() );

if ( empty( $product_list_image ) ) {
	$product_list_image = $product->get_image_id();
}

if ( $has_image ) {
	$image_dimension     = isset( $masonry_params['size'] ) && ! empty( $masonry_params['size'] ) ? esc_attr( $masonry_params['size'] ) : apply_filters( 'single_product_archive_thumbnail_size', 'woocommerce_thumbnail' );
	$custom_image_width  = 0;
	$custom_image_height = 0;

	echo neoocular_core_get_list_shortcode_item_image( $image_dimension, $product_list_image, $custom_image_width, $custom_image_height );
}
