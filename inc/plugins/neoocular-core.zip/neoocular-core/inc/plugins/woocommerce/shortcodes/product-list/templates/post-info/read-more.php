<div class="qodef-e-read-more">
	<?php
	$button_params = array(
		'link'          => get_permalink( get_the_ID() ),
		'button_layout' => 'outlined',
		'text'          => esc_html__( 'Read More', 'neoocular' ),
	);

	echo NeoOcularCore_Button_Shortcode::call_shortcode( $button_params );
	?>
</div>
