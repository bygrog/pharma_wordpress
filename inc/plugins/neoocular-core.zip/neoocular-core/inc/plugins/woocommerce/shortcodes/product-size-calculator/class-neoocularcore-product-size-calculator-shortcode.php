<?php

if ( ! function_exists( 'neoocular_core_add_product_size_calculator_shortcode' ) ) {
	/**
	 * Function that add shortcode into shortcodes list for registration
	 *
	 * @param array $shortcodes
	 *
	 * @return array
	 */
	function neoocular_core_add_product_size_calculator_shortcode( $shortcodes ) {
		$shortcodes[] = 'NeoOcularCore_Product_Size_Calculator_Shortcode';

		return $shortcodes;
	}

	add_filter( 'neoocular_core_filter_register_shortcodes', 'neoocular_core_add_product_size_calculator_shortcode', 8 );
}

if ( class_exists( 'NeoOcularCore_Shortcode' ) ) {
	class NeoOcularCore_Product_Size_Calculator_Shortcode extends NeoOcularCore_Shortcode {

		public function map_shortcode() {
			$this->set_shortcode_path( NEOOCULAR_CORE_PLUGINS_URL_PATH . '/woocommerce/shortcodes/product-size-calculator' );
			$this->set_base( 'neoocular_core_product_size_calculator' );
			$this->set_name( esc_html__( 'Product Size Calculator', 'neoocular-core' ) );
			$this->set_description( esc_html__( 'Shortcode that displays products based on their size', 'neoocular-core' ) );
			$this->set_category( esc_html__( 'NeoOcular Core', 'neoocular-core' ) );
			$this->set_option(
				array(
					'field_type' => 'text',
					'name'       => 'custom_class',
					'title'      => esc_html__( 'Custom Class', 'neoocular-core' ),
				)
			);
			$this->set_option(
				array(
					'field_type' => 'text',
					'name'       => 'title',
					'title'      => esc_html__( 'Title', 'neoocular-core' ),
				)
			);
			$this->set_option(
				array(
					'field_type' => 'select',
					'name'       => 'title_tag',
					'title'      => esc_html__( 'Title Tag', 'neoocular-core' ),
					'options'    => neoocular_core_get_select_type_options_pool( 'title_tag', true ),
				)
			);
			$this->set_option(
				array(
					'field_type' => 'text',
					'name'       => 'subtitle',
					'title'      => esc_html__( 'Subtitle', 'neoocular-core' ),
				)
			);
			$this->set_option(
				array(
					'field_type' => 'textarea',
					'name'       => 'text',
					'title'      => esc_html__( 'Text', 'neoocular-core' ),
				)
			);
			$this->set_option(
				array(
					'field_type' => 'text',
					'name'       => 'image_label_left',
					'title'      => esc_html__( 'Left Image Label', 'neoocular-core' ),
				)
			);
			$this->set_option(
				array(
					'field_type' => 'text',
					'name'       => 'image_label_bottom',
					'title'      => esc_html__( 'Bottom Image Label', 'neoocular-core' ),
				)
			);
		}

		public static function call_shortcode( $params ) {
			$html = qode_framework_call_shortcode( 'neoocular_core_product_size_calculator', $params );
			$html = str_replace( "\n", '', $html );

			return $html;
		}

		public function render( $options, $content = null ) {
			parent::render( $options );
			$atts = $this->get_atts();

			$atts['holder_classes'] = $this->get_holder_classes( $atts );

			return neoocular_core_get_template_part( 'plugins/woocommerce/shortcodes/product-size-calculator', 'templates/product-size-calculator', '', $atts );
		}

		private function get_holder_classes( $atts ) {
			$holder_classes = $this->init_holder_classes();

			$holder_classes[] = 'qodef-product-size-calculator';

			return implode( ' ', $holder_classes );
		}
	}
}
