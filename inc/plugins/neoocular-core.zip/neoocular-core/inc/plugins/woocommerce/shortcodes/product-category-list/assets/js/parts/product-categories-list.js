(function ( $ ) {
	'use strict';

	qodefCore.shortcodes.neoocular_core_product_category_list                    = {};
	qodefCore.shortcodes.neoocular_core_product_category_list.qodefMasonryLayout = qodef.qodefMasonryLayout;
	qodefCore.shortcodes.neoocular_core_product_category_list.qodefSwiper        = qodef.qodefSwiper;

})( jQuery );
