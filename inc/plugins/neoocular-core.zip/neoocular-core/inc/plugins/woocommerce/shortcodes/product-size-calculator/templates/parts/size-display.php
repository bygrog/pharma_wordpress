<div class="qodef-size-display">
	<div class="qodef-info">
		<span id="qodef-input-value"></span>
		<?php echo esc_html__( 'is closest to our', 'neoocular-core' ); ?>
		<span id="qodef-size-value"></span>
	</div>
	<div class="qodef-e-actions">
		<a href="<?php echo esc_url( wc_get_page_permalink( 'shop' ) ); ?>" class="qodef-button qodef-html--link qodef-layout--outlined">
			<span class="qodef-btn-text"><?php esc_html_e( 'Shop this size', 'neoocular-core' ); ?></span>
		</a>
		<button type="submit" class="qodef-button qodef-recalculate qodef-layout--textual">
			<span class="qodef-btn-text"><?php esc_html_e( 'Recalculate size', 'neoocular-core' ); ?></span>
		</button>
	</div>
</div>
