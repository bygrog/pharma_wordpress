<span class="woocommerce-loop-category__description">
	<?php echo esc_html( $category->description ); ?>
</span>
