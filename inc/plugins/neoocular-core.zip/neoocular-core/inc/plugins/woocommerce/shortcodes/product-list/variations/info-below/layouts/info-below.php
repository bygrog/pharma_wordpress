<li <?php wc_product_class( $item_classes ); ?>>
	<div class="qodef-e-inner">
		<?php if ( has_post_thumbnail() ) { ?>
			<div class="qodef-woo-product-image">
				<?php neoocular_core_template_part( 'plugins/woocommerce/shortcodes/product-list', 'templates/post-info/mark' ); ?>
				<?php neoocular_core_template_part( 'plugins/woocommerce/shortcodes/product-list', 'templates/post-info/image', '', $params ); ?>
				<?php neoocular_core_template_part( 'plugins/woocommerce/shortcodes/product-list', 'templates/post-info/link' ); ?>
			</div>
			<div class="qodef-woo-product-content"
				<?php
				$box_background = get_post_meta( get_the_ID(), 'qodef_product_list_box_color', true );
				if ( ! empty( $box_background ) ) {
					$content_styles[0] = 'background-color: ' . $box_background;
				}
				qode_framework_inline_style( $content_styles );
				?>
			>
				<?php neoocular_core_template_part( 'plugins/woocommerce/shortcodes/product-list', 'templates/post-info/color-variations', '', $params ); ?>
				<?php neoocular_core_template_part( 'plugins/woocommerce/shortcodes/product-list', 'templates/post-info/title', '', $params ); ?>
				<?php neoocular_core_template_part( 'plugins/woocommerce/shortcodes/product-list', 'templates/post-info/category', '', $params ); ?>
				<?php neoocular_core_template_part( 'plugins/woocommerce/shortcodes/product-list', 'templates/post-info/price', '', $params ); ?>
				<?php
				// Hook to include additional content inside product list item content
				do_action( 'neoocular_core_action_product_list_item_additional_content' );
				?>
				<div class="qodef-woo-product-image-inner">
					<?php
					neoocular_core_template_part( 'plugins/woocommerce/shortcodes/product-list', 'templates/post-info/add-to-cart' );

					// Hook to include additional content inside product list item image
					do_action( 'neoocular_core_action_product_list_item_additional_image_content' );
					?>
				</div>
			</div>
		<?php } ?>
	</div>
</li>
