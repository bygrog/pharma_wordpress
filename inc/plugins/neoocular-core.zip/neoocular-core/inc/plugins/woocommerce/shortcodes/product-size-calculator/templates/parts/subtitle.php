<?php if ( ! empty( $subtitle ) ) { ?>
	<span class="qodef-e-subtitle">
		<?php echo esc_html( $subtitle ); ?>
	</span>
<?php } ?>
