(function ( $ ) {
	'use strict';

	var shortcode = 'neoocular_core_product_list';

	$( document ).on(
		'ready',
		function () {
			qodefProductListDragIndicator.init();
		}
	);

	var qodefProductListDragIndicator = {
		init: function () {
			this.holder = $( '.qodef-woo-product-list.qodef-item-drag-indicator' );

			if ( this.holder.length ) {
				qodefCore.body.append( '<div class="qodef-woo-product-list-drag qodef-drag-holder"><div class="qodef-drag-inner"></div></div>' );

				var $followInfoHolder = $( '.qodef-woo-product-list-drag.qodef-drag-holder' ),
					$followText       = $followInfoHolder.find( '.qodef-drag-inner' );

				this.holder.each(
					function () {
						var $list      = $( this ),
							$infoItems = $list.find( '.qodef-woo-product-content, .swiper-pagination, .swiper-button-prev, .swiper-button-next' );

						$list.on(
							'mousemove',
							function ( e ) {

								$followInfoHolder.css(
									{
										top: e.clientY - 70,
										left: e.clientX - 70,
									}
								);
							}
						).on(
							'mouseenter',
							function () {
								var $thisFollowTitle = $( this ).find( '.qodef-drag-text' );

								if ( $thisFollowTitle.length ) {
									$followText.html( $thisFollowTitle.clone() );
								}

								if ( ! $followInfoHolder.hasClass( 'qodef-is-active' ) ) {
									$followInfoHolder.addClass( 'qodef-is-active' );
								}
							}
						).on(
							'mouseleave',
							function () {
								if ( $followInfoHolder.hasClass( 'qodef-is-active' ) ) {
									$followInfoHolder.removeClass( 'qodef-is-active' );
								}
							}
						);

						$list.on(
							'mouseenter',
							'.qodef-woo-product-content, .swiper-pagination, .swiper-button-prev, .swiper-button-next',
							function () {
								if ( $followInfoHolder.hasClass( 'qodef-is-active' ) ) {
									$followInfoHolder.removeClass( 'qodef-is-active' );
								}
							}
						).on(
							'mouseleave',
							'.qodef-woo-product-content, .swiper-pagination, .swiper-button-prev, .swiper-button-next',
							function () {
								if ( ! $followInfoHolder.hasClass( 'qodef-is-active' ) ) {
									$followInfoHolder.addClass( 'qodef-is-active' );
								}
							}
						);
					}
				);
			}
		}
	};

	qodefCore.shortcodes[shortcode] = {};

	if ( typeof qodefCore.listShortcodesScripts === 'object' ) {
		$.each(
			qodefCore.listShortcodesScripts,
			function ( key, value ) {
				qodefCore.shortcodes[shortcode][key] = value;
			}
		);
	}

	qodefCore.shortcodes[shortcode].qodefProductListDragIndicator = qodefProductListDragIndicator;

})( jQuery );
