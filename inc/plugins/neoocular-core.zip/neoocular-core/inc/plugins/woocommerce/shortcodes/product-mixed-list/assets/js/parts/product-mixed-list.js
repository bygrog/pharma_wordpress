(function ( $ ) {
	'use strict';

	var shortcode = 'neoocular_core_product_mixed_list';

	qodefCore.shortcodes[shortcode] = {};

	if ( typeof qodefCore.listShortcodesScripts === 'object' ) {
		$.each(
			qodefCore.listShortcodesScripts,
			function ( key, value ) {
				qodefCore.shortcodes[shortcode][key] = value;
			}
		);
	}

	$( document ).ready(
		function () {
			qodefProductMixedList.init();
		}
	);

	var qodefProductMixedList = {
		init: function () {
			this.items  = $( '.qodef-woo-product-mixed-list .qodef-item--landscape' );
			this.holder = $( '.qodef-woo-product-mixed-list' );

			if ( this.items.length ) {
				this.items.each(
					function () {
						var $thisItem = $( this );
						qodefProductMixedList.initHover( $thisItem );
					}
				);
			}

			if ( this.holder.length ) {
				this.holder.each(
					function () {
						var $thisHolder = $( this );
						qodefProductMixedList.initAppear( $thisHolder );
					}
				);
			}
		},
		initHover: function ( $holder ) {
			var $button = $holder.find( '.qodef-button' );

			$button.on(
				'mouseenter',
				function () {
					if ( ! $holder.hasClass( 'qodef--hovering' ) ) {
						$holder.addClass( 'qodef--hovering' );
					}
				}
			);
			$button.on(
				'mouseleave',
				function () {
					if ( $holder.hasClass( 'qodef--hovering' ) ) {
						$holder.removeClass( 'qodef--hovering' );
					}
				}
			);
		},
		initAppear: function ( $holder ) {
			qodefCore.qodefIsInViewport.check(
				$holder,
				function () {
					setTimeout(
						function () {
							$holder.addClass( 'qodef--appeared' );
						},
						600
					);
				}
			);
		},
	};

	qodefCore.shortcodes.neoocular_core_product_mixed_list.qodefProductMixedList = qodefProductMixedList;

})( jQuery );
