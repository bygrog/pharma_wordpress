<?php if ( ! empty( $text ) ) { ?>
	<p class="qodef-e-description">
		<?php echo esc_html( $text ); ?>
	</p>
<?php } ?>
