<?php
$button_params = array(
	'button_layout' => 'textual',
	'link'          => get_term_link( $category ),
	'text'          => esc_html__( 'Shop now', 'neoocular-core' ),
	'target'        => '_blank',
); ?>
<div class="qodef-m-button">
	<?php
	echo NeoOcularCore_Button_Shortcode::call_shortcode( $button_params );
	?>
</div>
