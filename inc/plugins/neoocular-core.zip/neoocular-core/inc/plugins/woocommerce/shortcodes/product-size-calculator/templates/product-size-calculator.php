<div <?php qode_framework_class_attribute( $holder_classes ); ?>>
	<div class="qodef-info-left">
		<?php
		// Include image
		neoocular_core_template_part( 'plugins/woocommerce/shortcodes/product-size-calculator', 'templates/parts/image', '', $params );
		?>
	</div>
	<div class="qodef-info-right">
		<?php
		// Include title
		neoocular_core_template_part( 'plugins/woocommerce/shortcodes/product-size-calculator', 'templates/parts/title', '', $params );

		// Include subtitle
		neoocular_core_template_part( 'plugins/woocommerce/shortcodes/product-size-calculator', 'templates/parts/subtitle', '', $params );

		// Include description
		neoocular_core_template_part( 'plugins/woocommerce/shortcodes/product-size-calculator', 'templates/parts/description', '', $params );

		// Include form
		neoocular_core_template_part( 'plugins/woocommerce/shortcodes/product-size-calculator', 'templates/parts/form', '', $params );
		?>
	</div>
</div>
