<h5 itemprop="name" class="qodef-woo-product-title entry-title" <?php qode_framework_inline_style( $this_shortcode->get_title_styles( $params ) ); ?>>
	<a itemprop="url" class="qodef-woo-product-title-link" href="<?php echo esc_url( $product->get_permalink() ); ?>">
		<?php echo esc_html( $product->get_title() ); ?>
	</a>
</h5>
