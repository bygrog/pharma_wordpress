<div class="qodef-e-form">
	<div class="qodef-size-search-form-inner">
		<input type="search" class="qodef-product-search-form-field" value="" name="filter_size" required="required" placeholder="<?php esc_attr_e( 'mm', 'neoocular-core' ); ?>"/>
		<?php
		//Include button
		neoocular_core_template_part( 'plugins/woocommerce/shortcodes/product-size-calculator', 'templates/parts/button', '', $params );
		?>
	</div>
	<?php
	// Include size
	neoocular_core_template_part( 'plugins/woocommerce/shortcodes/product-size-calculator', 'templates/parts/size-display', '', $params );
	?>
</div>
