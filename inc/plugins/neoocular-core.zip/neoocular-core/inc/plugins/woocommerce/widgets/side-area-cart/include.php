<?php

include_once NEOOCULAR_CORE_PLUGINS_PATH . '/woocommerce/widgets/side-area-cart/class-neoocularcore-woocommerce-side-area-cart-widget.php';
