<div class="qodef-cart-header-holder">
	<?php neoocular_core_template_part( 'plugins/woocommerce/widgets/side-area-cart', 'templates/parts/opener' ); ?>

	<h5 class="qodef-cart-title"><?php esc_html_e( 'my cart', 'neoocular' ); ?></h5>

	<a class="qodef-m-close" href="#">
		<span class="qodef-m-close-icon"><?php echo qode_framework_icons()->get_specific_icon_from_pack( 'close', 'elegant-icons' ); ?></span>
	</a>
</div>
