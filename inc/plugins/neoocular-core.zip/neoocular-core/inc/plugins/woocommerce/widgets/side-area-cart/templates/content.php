<?php if ( is_object( WC()->cart ) ) { ?>
<div class="qodef-widget-side-area-cart-content">
	<?php
	// Hook to include additional content before cart items
	do_action( 'neoocular_core_action_woocommerce_before_side_area_cart_content' );

	if ( ! WC()->cart->is_empty() ) {
		neoocular_core_template_part( 'plugins/woocommerce/widgets/side-area-cart', 'templates/parts/header' );

		neoocular_core_template_part( 'plugins/woocommerce/widgets/side-area-cart', 'templates/parts/loop' );

		neoocular_core_template_part( 'plugins/woocommerce/widgets/side-area-cart', 'templates/parts/order-details' );

		neoocular_core_template_part( 'plugins/woocommerce/widgets/side-area-cart', 'templates/parts/button' );
	} else {
		// Include posts not found
		neoocular_core_template_part( 'plugins/woocommerce/widgets/side-area-cart', 'templates/parts/posts-not-found' );
	}
	?>
</div>
<?php } ?>
