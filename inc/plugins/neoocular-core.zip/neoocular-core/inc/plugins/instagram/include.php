<?php

include_once NEOOCULAR_CORE_PLUGINS_PATH . '/instagram/helper.php';
