<?php

include_once NEOOCULAR_CORE_PLUGINS_PATH . '/instagram/shortcodes/instagram-list/widget/class-neoocularcore-instagram-list-widget.php';
