<?php

class NeoOcularCore_Booked_Calendar_Shortcode_Elementor extends NeoOcularCore_Elementor_Widget_Base {

	public function __construct( array $data = [], $args = null ) {
		$this->set_shortcode_slug( 'neoocular_core_booked_calendar' );

		parent::__construct( $data, $args );
	}
}

if ( qode_framework_is_installed( 'booked' ) ) {
	neoocular_core_get_elementor_widgets_manager()->register_widget_type( new NeoOcularCore_Booked_Calendar_Shortcode_Elementor() );
}
