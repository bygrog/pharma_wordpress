<?php

include_once NEOOCULAR_CORE_PLUGINS_PATH . '/booked/shortcodes/booked-calendar/class-neoocularcore-booked-calendar-shortcode.php';
