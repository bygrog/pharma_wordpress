<?php

include_once NEOOCULAR_CORE_INC_PATH . '/header/top-area/class-neoocularcore-top-area.php';
include_once NEOOCULAR_CORE_INC_PATH . '/header/top-area/helper.php';

foreach ( glob( NEOOCULAR_CORE_INC_PATH . '/header/top-area/dashboard/*/*.php' ) as $dashboard ) {
	include_once $dashboard;
}
