<?php do_action( 'neoocular_action_before_page_header' ); ?>

<header id="qodef-page-header" role="banner">
	<div id="qodef-page-header-inner" class="<?php echo implode( ' ', apply_filters( 'neoocular_filter_header_inner_class', array(), 'default' ) ); ?>">
		<?php
		// Include logo
		neoocular_core_get_header_logo_image();

		// Include divided left navigation
		neoocular_core_template_part( 'header', 'layouts/vertical/templates/navigation' );

		if ( is_active_sidebar( $sidebar ) ) {
			dynamic_sidebar( $sidebar );
		}

		?>
	</div>
</header>
