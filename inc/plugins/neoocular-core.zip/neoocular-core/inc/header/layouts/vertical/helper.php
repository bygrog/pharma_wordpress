<?php

if ( ! function_exists( 'neoocular_core_add_vertical_header_global_option' ) ) {
	/**
	 * This function set header type value for global header option map
	 */
	function neoocular_core_add_vertical_header_global_option( $header_layout_options ) {
		$header_layout_options['vertical'] = array(
			'image' => NEOOCULAR_CORE_HEADER_LAYOUTS_URL_PATH . '/vertical/assets/img/vertical-header.png',
			'label' => esc_html__( 'Vertical', 'neoocular-core' ),
		);

		return $header_layout_options;
	}

	add_filter( 'neoocular_core_filter_header_layout_option', 'neoocular_core_add_vertical_header_global_option' );
}

if ( ! function_exists( 'neoocular_core_register_vertical_header_layout' ) ) {
	/**
	 * Function which add header layout into global list
	 *
	 * @param array $header_layouts
	 *
	 * @return array
	 */
	function neoocular_core_register_vertical_header_layout( $header_layouts ) {
		$header_layouts['vertical'] = 'NeoOcularCore_Vertical_Header';

		return $header_layouts;
	}

	add_filter( 'neoocular_core_filter_register_header_layouts', 'neoocular_core_register_vertical_header_layout' );
}

if ( ! function_exists( 'neoocular_core_vertical_header_nav_menu_grid' ) ) {
	/**
	 * Function which set grid class name for current header layout
	 *
	 * @param string $grid_class
	 *
	 * @return string
	 */
	function neoocular_core_vertical_header_nav_menu_grid( $grid_class ) {
		$header = neoocular_core_get_post_value_through_levels( 'qodef_header_layout' );

		if ( 'vertical' === $header ) {
			return false;
		}

		return $grid_class;
	}

	add_filter( 'neoocular_core_filter_drop_down_grid', 'neoocular_core_vertical_header_nav_menu_grid' );
}

if ( ! function_exists( 'neoocular_core_register_vertical_menu' ) ) {
	/**
	 * Function which add additional main menu navigation into global list
	 *
	 * @param array $menus
	 *
	 * @return array
	 */
	function neoocular_core_register_vertical_menu( $menus ) {
		$menus['vertical-menu-navigation'] = esc_html__( 'Vertical Navigation', 'neoocular-core' );

		return $menus;
	}

	add_filter( 'neoocular_filter_register_navigation_menus', 'neoocular_core_register_vertical_menu' );
}

if ( ! function_exists( 'neoocular_core_vertical_header_hide_top_area' ) ) {
	/**
	 * Function that set dependency option value for specific module layout
	 *
	 * @param array $options
	 *
	 * @return array
	 */
	function neoocular_core_vertical_header_hide_top_area( $options ) {
		$options[] = 'vertical';

		return $options;
	}

	add_filter( 'neoocular_core_filter_top_area_hide_option', 'neoocular_core_vertical_header_hide_top_area' );
}

if ( ! function_exists( 'neoocular_core_vertical_header_hide_scroll_appearance' ) ) {
	/**
	 * Function that set dependency option value for specific module layout
	 *
	 * @param array $options
	 *
	 * @return array
	 */
	function neoocular_core_vertical_header_hide_scroll_appearance( $options ) {
		$options[] = 'vertical';

		return $options;
	}

	add_filter( 'neoocular_core_filter_header_scroll_appearance_hide_option', 'neoocular_core_vertical_header_hide_scroll_appearance' );
}

if ( ! function_exists( 'neoocular_core_get_vertical_header_config' ) ) {
	/**
	 * Function that return config variables for side area
	 *
	 * @return array
	 */
	function neoocular_core_get_vertical_header_config() {

		// Config variables
		$config = apply_filters(
			'neoocular_core_vertical_header_config',
			array(
				'title_tag'   => 'span',
				'title_class' => 'qodef-widget-title',
			)
		);

		return $config;
	}
}

if ( ! function_exists( 'neoocular_core_register_vertical_header_sidebar' ) ) {
	/**
	 * Register content bottom sidebar
	 */
	function neoocular_core_register_vertical_header_sidebar() {
		// Sidebar config variables
		$config = neoocular_core_get_vertical_header_config();

		register_sidebar(
			array(
				'id'            => 'qodef-vertical-header',
				'name'          => esc_html__( 'Vertical Header', 'neoocular-core' ),
				'description'   => esc_html__( 'Widgets added here will appear in vertical header', 'neoocular-core' ),
				'before_widget' => '<div id="%1$s" class="widget %2$s" data-area="side-area">',
				'after_widget'  => '</div>',
				'before_title'  => '<' . esc_attr( $config['title_tag'] ) . ' class="' . esc_attr( $config['title_class'] ) . '">',
				'after_title'   => '</' . esc_attr( $config['title_tag'] ) . '>',
			)
		);
	}

	add_action( 'widgets_init', 'neoocular_core_register_vertical_header_sidebar' );
}
