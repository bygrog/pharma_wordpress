<?php

include_once NEOOCULAR_CORE_INC_PATH . '/header/layouts/minimal/helper.php';
include_once NEOOCULAR_CORE_INC_PATH . '/header/layouts/minimal/class-neoocularcore-minimal-header.php';
include_once NEOOCULAR_CORE_INC_PATH . '/header/layouts/minimal/dashboard/admin/minimal-header-options.php';
include_once NEOOCULAR_CORE_INC_PATH . '/header/layouts/minimal/dashboard/meta-box/minimal-header-meta-box.php';
