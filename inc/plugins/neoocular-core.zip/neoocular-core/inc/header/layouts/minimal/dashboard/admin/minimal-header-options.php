<?php

if ( ! function_exists( 'neoocular_core_add_minimal_header_options' ) ) {
	/**
	 * Function that add additional header layout options
	 *
	 * @param object $page
	 * @param array  $general_header_tab
	 */
	function neoocular_core_add_minimal_header_options( $page, $general_header_tab ) {

		$section = $general_header_tab->add_section_element(
			array(
				'name'       => 'qodef_minimal_header_section',
				'title'      => esc_html__( 'Minimal Header', 'neoocular-core' ),
				'dependency' => array(
					'show' => array(
						'qodef_header_layout' => array(
							'values'        => 'minimal',
							'default_value' => '',
						),
					),
				),
			)
		);

		$section->add_field_element(
			array(
				'field_type'    => 'yesno',
				'name'          => 'qodef_minimal_header_in_grid',
				'title'         => esc_html__( 'Content in Grid', 'neoocular-core' ),
				'description'   => esc_html__( 'Set content to be in grid', 'neoocular-core' ),
				'default_value' => 'no',
			)
		);

		$section->add_field_element(
			array(
				'field_type'  => 'text',
				'name'        => 'qodef_minimal_header_height',
				'title'       => esc_html__( 'Header Height', 'neoocular-core' ),
				'description' => esc_html__( 'Enter header height', 'neoocular-core' ),
				'args'        => array(
					'suffix' => esc_html__( 'px', 'neoocular-core' ),
				),
			)
		);

		$section->add_field_element(
			array(
				'field_type'  => 'text',
				'name'        => 'qodef_minimal_header_side_padding',
				'title'       => esc_html__( 'Header Side Padding', 'neoocular-core' ),
				'description' => esc_html__( 'Enter side padding for header area', 'neoocular-core' ),
				'args'        => array(
					'suffix' => esc_html__( 'px or %', 'neoocular-core' ),
				),
			)
		);

		$section->add_field_element(
			array(
				'field_type'  => 'color',
				'name'        => 'qodef_minimal_header_background_color',
				'title'       => esc_html__( 'Header Background Color', 'neoocular-core' ),
				'description' => esc_html__( 'Enter header background color', 'neoocular-core' ),
			)
		);

		$section->add_field_element(
			array(
				'field_type'  => 'color',
				'name'        => 'qodef_minimal_header_border_color',
				'title'       => esc_html__( 'Header Border Color', 'neoocular-core' ),
				'description' => esc_html__( 'Enter header border color', 'neoocular-core' ),
			)
		);

		$section->add_field_element(
			array(
				'field_type'  => 'text',
				'name'        => 'qodef_minimal_header_border_width',
				'title'       => esc_html__( 'Header Border Width', 'neoocular-core' ),
				'description' => esc_html__( 'Enter header border width size', 'neoocular-core' ),
				'args'        => array(
					'suffix' => esc_html__( 'px', 'neoocular-core' ),
				),
			)
		);

		$section->add_field_element(
			array(
				'field_type'  => 'select',
				'name'        => 'qodef_minimal_header_border_style',
				'title'       => esc_html__( 'Header Border Style', 'neoocular-core' ),
				'description' => esc_html__( 'Choose header border style', 'neoocular-core' ),
				'options'     => neoocular_core_get_select_type_options_pool( 'border_style' ),
			)
		);
	}

	add_action( 'neoocular_core_action_after_header_options_map', 'neoocular_core_add_minimal_header_options', 10, 2 );
}
