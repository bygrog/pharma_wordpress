<?php neoocular_core_get_header_logo_image(); ?>
	<div class="qodef-widget-holder qodef--one">
		<?php neoocular_core_get_header_widget_area(); ?>
	</div>
<?php
neoocular_core_get_opener_icon_html(
	array(
		'option_name'  => 'fullscreen_menu',
		'custom_class' => 'qodef-fullscreen-menu-opener',
	),
	true
);
?>
