<?php

include_once NEOOCULAR_CORE_INC_PATH . '/blog/templates/single/related-posts/helper.php';
include_once NEOOCULAR_CORE_INC_PATH . '/blog/templates/single/related-posts/dashboard/admin/related-posts-options.php';
