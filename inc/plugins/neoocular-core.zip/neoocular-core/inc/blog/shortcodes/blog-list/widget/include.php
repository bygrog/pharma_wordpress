<?php

include_once NEOOCULAR_CORE_INC_PATH . '/blog/shortcodes/blog-list/widget/class-neoocularcore-blog-list-widget.php';
include_once NEOOCULAR_CORE_INC_PATH . '/blog/shortcodes/blog-list/widget/class-neoocularcore-simple-blog-list-widget.php';
