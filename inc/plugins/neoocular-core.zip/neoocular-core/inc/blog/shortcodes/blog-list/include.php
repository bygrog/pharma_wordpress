<?php

include_once NEOOCULAR_CORE_INC_PATH . '/blog/shortcodes/blog-list/class-neoocularcore-blog-list-shortcode.php';

foreach ( glob( NEOOCULAR_CORE_INC_PATH . '/blog/shortcodes/blog-list/variations/*/include.php' ) as $variation ) {
	include_once $variation;
}
