<?php

include_once NEOOCULAR_CORE_INC_PATH . '/blog/shortcodes/blog-list/variations/metro/metro.php';
