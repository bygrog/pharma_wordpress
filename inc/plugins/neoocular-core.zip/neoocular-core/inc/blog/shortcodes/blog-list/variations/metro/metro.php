<?php

if ( ! function_exists( 'neoocular_core_add_blog_list_variation_metro' ) ) {
	/**
	 * Function that add variation layout for this module
	 *
	 * @param array $variations
	 *
	 * @return array
	 */
	function neoocular_core_add_blog_list_variation_metro( $variations ) {
		$variations['metro'] = esc_html__( 'Metro', 'neoocular-core' );

		return $variations;
	}

	add_filter( 'neoocular_core_filter_blog_list_layouts', 'neoocular_core_add_blog_list_variation_metro' );
}
