<?php

if ( ! function_exists( 'neoocular_core_add_blog_list_variation_simple' ) ) {
	/**
	 * Function that add variation layout for this module
	 *
	 * @param array $variations
	 *
	 * @return array
	 */
	function neoocular_core_add_blog_list_variation_simple( $variations ) {
		$variations['simple'] = esc_html__( 'Simple', 'neoocular-core' );

		return $variations;
	}

	add_filter( 'neoocular_core_filter_blog_list_layouts', 'neoocular_core_add_blog_list_variation_simple' );
	add_filter( 'neoocular_core_filter_simple_blog_list_widget_layouts', 'neoocular_core_add_blog_list_variation_simple' );
}
