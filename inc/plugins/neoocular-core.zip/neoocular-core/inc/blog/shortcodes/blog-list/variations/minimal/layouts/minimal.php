<article <?php post_class( $item_classes ); ?>>
	<div class="qodef-e-inner">
		<?php
		if ( 'yes' === $show_image ) {
			// Include post media
			neoocular_core_template_part( 'blog/shortcodes/blog-list', 'templates/post-info/media', '', $params );
		}
		?>
		<div class="qodef-e-content">
			<div class="qodef-e-top-holder" <?php qode_framework_inline_style( $top_holder_style ); ?>>
				<div class="qodef-e-info">
					<?php
					// Include post date info
					neoocular_core_theme_template_part( 'blog', 'templates/parts/post-info/date' );

					// Include post category info
					neoocular_core_theme_template_part( 'blog', 'templates/parts/post-info/categories' );
					?>
				</div>
			</div>
			<div class="qodef-e-text">
				<?php
				// Include post title
				neoocular_core_template_part( 'blog/shortcodes/blog-list', 'templates/post-info/title', '', $params );
				?>
			</div>
		</div>
	</div>
</article>
