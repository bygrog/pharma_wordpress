<?php

include_once NEOOCULAR_CORE_INC_PATH . '/opener-icon/helper.php';
