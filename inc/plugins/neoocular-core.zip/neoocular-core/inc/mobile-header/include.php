<?php

include_once NEOOCULAR_CORE_INC_PATH . '/mobile-header/helper.php';
include_once NEOOCULAR_CORE_INC_PATH . '/mobile-header/class-neoocularcore-mobile-header.php';
include_once NEOOCULAR_CORE_INC_PATH . '/mobile-header/class-neoocularcore-mobile-headers.php';
include_once NEOOCULAR_CORE_INC_PATH . '/mobile-header/template-functions.php';
