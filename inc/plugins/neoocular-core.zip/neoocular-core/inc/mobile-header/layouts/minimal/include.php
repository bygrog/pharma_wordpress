<?php

include_once NEOOCULAR_CORE_INC_PATH . '/mobile-header/layouts/minimal/helper.php';
include_once NEOOCULAR_CORE_INC_PATH . '/mobile-header/layouts/minimal/class-neoocularcore-minimal-mobile-header.php';
include_once NEOOCULAR_CORE_INC_PATH . '/mobile-header/layouts/minimal/dashboard/admin/minimal-mobile-header-options.php';
