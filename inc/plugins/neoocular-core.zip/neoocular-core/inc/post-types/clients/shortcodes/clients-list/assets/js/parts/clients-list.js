(function ( $ ) {
	'use strict';

	qodefCore.shortcodes.neoocular_core_clients_list             = {};
	qodefCore.shortcodes.neoocular_core_clients_list.qodefSwiper = qodef.qodefSwiper;

})( jQuery );
