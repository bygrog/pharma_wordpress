<?php

include_once NEOOCULAR_CORE_CPT_PATH . '/clients/shortcodes/clients-list/class-neoocularcore-clients-list-shortcode.php';

foreach ( glob( NEOOCULAR_CORE_CPT_PATH . '/clients/shortcodes/clients-list/variations/*/include.php' ) as $variation ) {
	include_once $variation;
}
