<?php

include_once NEOOCULAR_CORE_INC_PATH . '/content/helper.php';
