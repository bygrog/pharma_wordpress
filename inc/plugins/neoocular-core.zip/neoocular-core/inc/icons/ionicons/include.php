<?php

include_once NEOOCULAR_CORE_INC_PATH . '/icons/ionicons/class-neoocularcore-ionicons-pack.php';
