<?php

include_once NEOOCULAR_CORE_INC_PATH . '/icons/simple-line-icons/class-neoocularcore-simple-line-icons-pack.php';
