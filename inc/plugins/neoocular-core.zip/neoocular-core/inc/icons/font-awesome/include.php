<?php

include_once NEOOCULAR_CORE_INC_PATH . '/icons/font-awesome/class-neoocularcore-font-awesome-pack.php';
