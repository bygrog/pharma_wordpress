<?php

foreach ( glob( NEOOCULAR_MEMBERSHIP_INC_PATH . '/general/dashboard/admin/*.php' ) as $module ) {
	include_once $module;
}

require_once NEOOCULAR_MEMBERSHIP_INC_PATH . '/general/class-neoocularmembership-page-templates.php';
include_once NEOOCULAR_MEMBERSHIP_INC_PATH . '/general/helper.php';
