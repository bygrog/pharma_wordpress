<?php

if ( ! function_exists( 'neoocular_membership_add_general_options' ) ) {
	/**
	 * Function that add general options for this module
	 */
	function neoocular_membership_add_general_options() {
		$qode_framework = qode_framework_get_framework_root();

		$page = $qode_framework->add_options_page(
			array(
				'scope'       => NEOOCULAR_CORE_OPTIONS_NAME,
				'type'        => 'admin',
				'slug'        => 'membership',
				'icon'        => 'fa fa-envelope',
				'title'       => esc_html__( 'Membership', 'neoocular-membership' ),
				'description' => esc_html__( 'Membership Settings', 'neoocular-membership' ),
			)
		);

		if ( $page ) {

			$page->add_field_element(
				array(
					'field_type'    => 'yesno',
					'name'          => 'qodef_membership_privacy_policy_enabled',
					'title'         => esc_html__( 'Enable Privacy Policy Text', 'neoocular-membership' ),
					'default_value' => 'yes',
				)
			);

			$page->add_field_element(
				array(
					'field_type'  => 'text',
					'name'        => 'qodef_membership_privacy_policy_text',
					'title'       => esc_html__( 'Privacy Policy Text', 'neoocular-membership' ),
					'description' => esc_html__( 'Enter privacy policy text for registration modal form', 'neoocular-membership' ),
					'dependency'  => array(
						'show' => array(
							'qodef_membership_privacy_policy_enabled' => array(
								'values'        => 'yes',
								'default_value' => 'no',
							),
						),
					),
				)
			);

			$page->add_field_element(
				array(
					'field_type'  => 'select',
					'name'        => 'qodef_membership_privacy_policy_link',
					'title'       => esc_html__( 'Privacy Policy Link', 'neoocular-membership' ),
					'description' => esc_html__( 'Choose "Privacy Policy Link" page to link from registration modal form', 'neoocular-membership' ),
					'options'     => qode_framework_get_pages( true ),
					'dependency'  => array(
						'show' => array(
							'qodef_membership_privacy_policy_enabled' => array(
								'values'        => 'yes',
								'default_value' => 'no',
							),
						),
					),
				)
			);

			$page->add_field_element(
				array(
					'field_type'  => 'text',
					'name'        => 'qodef_membership_privacy_policy_link_text',
					'title'       => esc_html__( 'Privacy Policy Link Text', 'neoocular-membership' ),
					'description' => esc_html__( 'Enter privacy policy link text for registration modal form. Default value is "privacy policy"', 'neoocular-membership' ),
					'dependency'  => array(
						'show' => array(
							'qodef_membership_privacy_policy_enabled' => array(
								'values'        => 'yes',
								'default_value' => 'no',
							),
						),
					),
				)
			);

			// Hook to include additional options after module options
			do_action( 'neoocular_membership_action_after_membership_options_map', $page );
		}
	}

	add_action( 'neoocular_core_action_default_options_init', 'neoocular_membership_add_general_options', 70 );
}
