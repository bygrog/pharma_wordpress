<?php

include_once NEOOCULAR_MEMBERSHIP_INC_PATH . '/widgets/login-opener/class-neoocularmembership-login-opener-widget.php';
