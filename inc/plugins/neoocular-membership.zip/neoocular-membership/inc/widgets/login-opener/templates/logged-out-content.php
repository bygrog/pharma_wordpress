<a href="#" class="qodef-login-opener">
	<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="16.289px" height="16.087px" viewBox="0 0 16.289 16.087" enable-background="new 0 0 16.289 16.087" xml:space="preserve">
		<circle fill="none" stroke="currentColor" stroke-miterlimit="10" cx="8.144" cy="4.594" r="4.094"/>
		<path fill="none" stroke="currentColor" stroke-miterlimit="10" d="M15.677,15.587c-0.633-3.107-3.76-5.469-7.532-5.469 c-3.772,0-6.899,2.362-7.532,5.469H15.677z"/>
	</svg>
</a>
