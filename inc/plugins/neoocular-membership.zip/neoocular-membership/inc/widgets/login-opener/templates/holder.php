<?php

if ( is_user_logged_in() ) {
	neoocular_membership_template_part( 'widgets/login-opener', 'templates/logged-in-content' );
} else {
	neoocular_membership_template_part( 'widgets/login-opener', 'templates/logged-out-content' );
}
