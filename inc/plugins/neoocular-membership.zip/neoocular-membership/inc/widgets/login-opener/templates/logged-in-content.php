<?php
$current_user = wp_get_current_user();
?>
<div class="qodef-logged-in-user qodef-m">
	<div class="qodef-m-user">
		<span class="qodef-m-user-image">
			<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="16.289px" height="16.087px" viewBox="0 0 16.289 16.087" enable-background="new 0 0 16.289 16.087" xml:space="preserve">
				<circle fill="none" stroke="currentColor" stroke-miterlimit="10" cx="8.144" cy="4.594" r="4.094"/>
				<path fill="none" stroke="currentColor" stroke-miterlimit="10" d="M15.677,15.587c-0.633-3.107-3.76-5.469-7.532-5.469 c-3.772,0-6.899,2.362-7.532,5.469H15.677z"/>
			</svg>
		</span>
	</div>
	<ul class="qodef-m-navigation-items">
		<?php
		$dashboard_url = neoocular_membership_get_dashboard_page_url();
		$nav_items     = neoocular_membership_get_dashboard_navigation_pages();

		if ( ! empty( $dashboard_url ) ) {
			$user_action = isset( $_GET['user-action'] ) ? sanitize_text_field( $_GET['user-action'] ) : 'profile';

			foreach ( $nav_items as $nav_item ) {
				$active_class = $nav_item['user_action'] === $user_action ? 'qodef--active' : '';
				?>
				<li class="qodef-m-navigation-item qodef-e <?php echo esc_attr( $active_class ); ?>">
					<a class="qodef-e-link" href="<?php echo esc_url( $nav_item['url'] ); ?>">
						<?php if ( isset( $nav_item['icon'] ) && ! empty( $nav_item['icon'] ) ) { ?>
							<span class="qodef-e-icon"><?php echo wp_kses_post( $nav_item['icon'] ); ?></span>
						<?php } ?>
						<span class="qodef-e-label"><?php echo wp_kses( $nav_item['text'], array( 'span' => array( 'class' => true ) ) ); ?></span>
					</a>
				</li>
				<?php
			}
		} else {
			?>
			<li class="qodef-m-navigation-item qodef-e">
				<a class="qodef-e-link" href="<?php echo esc_url( $nav_items['log-out']['url'] ); ?>">
					<?php if ( isset( $nav_items['log-out']['icon'] ) && ! empty( $nav_items['log-out']['icon'] ) ) { ?>
						<span class="qodef-e-icon"><?php echo wp_kses_post( $nav_items['log-out']['icon'] ); ?></span>
					<?php } ?>
					<span class="qodef-e-label"><?php echo wp_kses( $nav_items['log-out']['text'], array( 'span' => array( 'class' => true ) ) ); ?></span>
				</a>
			</li>
		<?php } ?>
	</ul>
</div>
